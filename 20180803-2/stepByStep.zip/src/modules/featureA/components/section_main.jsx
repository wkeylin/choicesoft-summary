import React, {Component} from 'react';
import ReactDom from 'react-dom';
import { connect } from 'react-redux'; // 引入connect
import { setNum } from '../action.js';
import { Rate } from 'antd';

class Main extends Component {
  constructor(props) {
    super(props);
    this.state = {
    }
    this.changeNum=this.changeNum.bind(this);
  }

  componentWillReceiveProps(nextProps) {
  }

  componentDidMount() {
  }
  changeNum(value){
    value = value * 2;
    const { setNum } = this.props;
    setNum(value)
  }
  render() {
    const {name, size} = this.state;
    const {theNumber} = this.props.dataA;
    return (
      <div style={{border:'1px solid #533eb4', backgroundColor: '#cfcaf6', margin: 10, padding: 10, height: '50vh'}}>
        this is Main component!
        <Rate allowHalf count={10} value={theNumber/2} onChange={this.changeNum}/>
        <span style={{margin:"0 10px", display:"inline-block"}}>{theNumber}</span>
        问题2：怎样创建一个自定义图标的Rate组件？
      </div>
    )
  }
}

const propertys = state => {
  return { dataA: state.rootData.featureA.pageData };
}
Main = connect(propertys, {setNum})(Main);
module.exports = Main;
