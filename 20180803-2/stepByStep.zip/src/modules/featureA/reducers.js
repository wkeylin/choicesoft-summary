import { combineReducers } from 'redux'
import TYPES from '../$redux/rootTypes.js' // How to refs it beautiful?

const initialList = {
  theNumber: 0,
  theString:"initial string!",
}

export default combineReducers({
  pageData:function(state = initialList, action) {//�����б�
    // console.log("dataList",action);
    switch (action.type) {
      case TYPES.FEATURE_A.ADD_1:
        return Object.assign({}, state, { theNumber: state.theNumber + 1 });
        break;
      case TYPES.FEATURE_A.REDUCE_1:
        return Object.assign({}, state, { theNumber: state.theNumber - 1 });
        break;
      case TYPES.FEATURE_A.SET_NUMBER:
        return Object.assign({}, state, { theNumber: action.value });
        break;
      case TYPES.FEATURE_B.TEST_ACTION:
        return Object.assign({}, state, { theString: theString.split('').reverse().join('') });
      default:
        return state;
    }
  },
})
