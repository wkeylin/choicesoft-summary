// action常量
module.exports = {
  FEATURE_A: {
    ADD_1: "this_is_an_add_ops", // 用于加一
    SET_NUMBER: "set_a_number_by_value",
    REDUCE_1:"this_is_an_reduce_ops", // 用于-
  },
  FEATURE_B: {
    TEST_ACTION: "this_is_a_test_action_for_featureB", // 测试用
  },
  FEATURE_C: {
    TEST_ACTION: "this_is_a_test_action_for_featureC", // 测试用
  },
}
