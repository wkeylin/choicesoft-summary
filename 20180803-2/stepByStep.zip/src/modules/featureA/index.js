import featureA from './components/sectionHub.jsx'
module.exports = {
  featureA
}
